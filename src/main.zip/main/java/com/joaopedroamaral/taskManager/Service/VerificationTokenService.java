package com.joaopedroamaral.taskManager.Service;

import com.joaopedroamaral.taskManager.DTO.UserResponseDTO;
import com.joaopedroamaral.taskManager.DTO.VerificationTokenDTO;
import com.joaopedroamaral.taskManager.Entity.User;
import com.joaopedroamaral.taskManager.Entity.VerificationToken;
import com.joaopedroamaral.taskManager.Repository.UserRepository;
import com.joaopedroamaral.taskManager.Repository.VerificationTokenRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.UUID;

@Service
public class VerificationTokenService {

    private final UserRepository userRepository;

    private final VerificationTokenRepository verificationTokenRepository;

    public VerificationTokenService(UserRepository userRepository, VerificationTokenRepository verificationTokenRepository){
        this.userRepository = userRepository;
        this.verificationTokenRepository = verificationTokenRepository;
    }

    public String createToken(){
        return UUID.randomUUID().toString();
    }

    public void Authenticate(String token, String email){
        VerificationToken verificationToken = verificationTokenRepository.findById(token).
                orElseThrow(()-> new RuntimeException("Invalid token"));

        if(verificationToken.getLocalDateTime().isBefore(LocalDateTime.now())){
            throw new RuntimeException("Expired time");
        }
        User user = userRepository.findByEmail(email).orElseThrow(() -> new RuntimeException("User not found"));
        user.setEnabled(true);
        verificationTokenRepository.deleteById(verificationToken.getToken());
    }
}
