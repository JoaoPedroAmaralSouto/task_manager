package com.joaopedroamaral.taskManager.DTO;

public record CompanyRequestDTO(String companyName) {
}
