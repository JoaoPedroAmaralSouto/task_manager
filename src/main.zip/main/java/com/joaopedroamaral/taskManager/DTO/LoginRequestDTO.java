package com.joaopedroamaral.taskManager.DTO;

public record LoginRequestDTO(String email,
                              String password) {
}
