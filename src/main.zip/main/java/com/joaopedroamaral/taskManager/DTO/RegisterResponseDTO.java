package com.joaopedroamaral.taskManager.DTO;

public record RegisterResponseDTO(String message) {
}
