package com.joaopedroamaral.taskManager.Entity;

public enum Status {
    PENDING,
    RUNNING,
    COMPLETED
}
